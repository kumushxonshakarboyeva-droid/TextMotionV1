# TextMotion V1

Telegram-first animated text/sticker Mini App frontend.

## Features

- 20 animation presets
- Live preview
- Text editor
- Font selection
- Color selection
- Size and speed controls
- Loop control
- Telegram WebApp initialization
- Export UI placeholder

## Run locally

```bash
npm install
npm run dev
```

Build:

```bash
npm run build
```

## V2

Connect a rendering backend (Playwright/Canvas + FFmpeg) to create transparent WEBM and Telegram sticker/emoji exports.
