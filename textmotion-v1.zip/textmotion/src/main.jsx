import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";

const animations = [
  ["fade","Fade","🌫️","basic","anim-fade"],
  ["slide-up","Slide Up","⬆️","basic","anim-slide-up"],
  ["slide-down","Slide Down","⬇️","basic","anim-slide-down"],
  ["slide-left","Slide Left","⬅️","basic","anim-slide-left"],
  ["slide-right","Slide Right","➡️","basic","anim-slide-right"],
  ["scale","Scale","🔎","basic","anim-scale"],
  ["zoom","Zoom","💫","basic","anim-zoom"],
  ["bounce","Bounce","🏀","fun","anim-bounce"],
  ["elastic","Elastic","🪀","fun","anim-elastic"],
  ["shake","Shake","💥","fun","anim-shake"],
  ["wobble","Wobble","〰️","fun","anim-wobble"],
  ["swing","Swing","🎪","fun","anim-swing"],
  ["wave","Wave","🌊","fun","anim-wave"],
  ["typewriter","Typewriter","⌨️","typography","anim-typewriter"],
  ["letter-reveal","Letter Reveal","🔤","typography","anim-letter"],
  ["word-reveal","Word Reveal","📝","typography","anim-word"],
  ["blur","Blur Reveal","✨","typography","anim-blur"],
  ["glitch","Glitch","⚡","effects","anim-glitch"],
  ["neon","Neon","💡","effects","anim-neon"],
  ["extrude","3D Extrude","🧊","effects","anim-extrude"]
].map(([id,name,icon,category,className]) => ({id,name,icon,category,className}));

const categories = [
  ["all","All","✨"],["basic","Basic","🎬"],["fun","Fun","🔥"],
  ["typography","Text","🔤"],["effects","Effects","⚡"]
];

const fonts = ["Inter","Arial","Georgia","Impact","Courier New","Trebuchet MS"];
const colors = ["#ffffff","#ff4d67","#ffcc00","#36e17b","#3da5ff","#a56cff","#ff7b22"];

function tgHaptic(type="light"){
  try { window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(type); } catch {}
}
function initTelegram(){
  const tg = window.Telegram?.WebApp;
  if (!tg) return;
  tg.ready(); tg.expand();
  tg.setHeaderColor?.("#0f1014");
  tg.setBackgroundColor?.("#0f1014");
}

function Preview({text, animationId, color, font, speed, loop, size}){
  const a = animations.find(x=>x.id===animationId) || animations[7];
  return <div className="preview-stage">
    <div className="transparent-grid"/>
    <div className="preview-content">
      <div key={`${animationId}-${text}-${speed}`} className={`preview-text ${a.className}`}
        style={{color,fontFamily:font,fontSize:`${size}px`,animationDuration:`${speed}s`,animationIterationCount:loop?"infinite":"1"}}>
        {text || "Your text"}
      </div>
    </div>
    <div className="preview-label">LIVE PREVIEW</div>
  </div>
}

function Picker({selected,onSelect,onClose}){
  const [cat,setCat]=useState("all");
  const [search,setSearch]=useState("");
  const filtered=animations.filter(a=>(cat==="all"||a.category===cat)&&a.name.toLowerCase().includes(search.toLowerCase()));
  return <div className="picker-overlay"><div className="picker">
    <div className="picker-header"><div><h2>Animations</h2><p>Choose a motion style</p></div><button className="icon-button" onClick={onClose}>×</button></div>
    <div className="search-box">🔍<input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search animations..."/></div>
    <div className="filter-row">{categories.map(([id,name,icon])=><button key={id} className={cat===id?"filter active":"filter"} onClick={()=>setCat(id)}>{icon} {name}</button>)}</div>
    <div className="animation-grid">{filtered.map(a=><button key={a.id} className={selected===a.id?"animation-card selected":"animation-card"} onClick={()=>{onSelect(a.id);onClose()}}>
      <div className={`animation-demo ${a.className}`}>Aa</div><div className="animation-name">{a.icon} {a.name}</div>
    </button>)}</div>
  </div></div>
}

function Editor({initialAnimation,onBack,onExport}){
  const [text,setText]=useState("Hello!");
  const [animationId,setAnimationId]=useState(initialAnimation);
  const [font,setFont]=useState("Inter");
  const [color,setColor]=useState("#ffffff");
  const [speed,setSpeed]=useState(1);
  const [loop,setLoop]=useState(true);
  const [size,setSize]=useState(64);
  const [picker,setPicker]=useState(false);
  const animation=animations.find(a=>a.id===animationId);
  const exportProject=()=>{tgHaptic("medium");onExport({text,animationId,font,color,speed,loop,size})};

  return <div className="editor-page">
    <header className="topbar"><button className="icon-button" onClick={onBack}>‹</button><div className="topbar-title">Create</div><button className="text-button" onClick={exportProject}>Export</button></header>
    <main className="editor-content">
      <Preview text={text} animationId={animationId} color={color} font={font} speed={speed} loop={loop} size={size}/>
      <section className="controls">
        <div className="control-section"><label>Text</label><textarea value={text} onChange={e=>setText(e.target.value.slice(0,80))} rows="2" placeholder="Type your text..."/><div className="character-count">{text.length}/80</div></div>
        <div className="control-section"><div className="control-title"><label>Animation</label><button className="see-all" onClick={()=>setPicker(true)}>See all</button></div>
          <button className="selected-animation" onClick={()=>setPicker(true)}><div className="selected-animation-icon">{animation?.icon}</div><div><strong>{animation?.name}</strong><span>Tap to change animation</span></div><span className="arrow">›</span></button>
        </div>
        <div className="control-section"><label>Font</label><div className="font-row">{fonts.map(f=><button key={f} className={font===f?"font-chip selected":"font-chip"} style={{fontFamily:f}} onClick={()=>{setFont(f);tgHaptic()}}>Aa</button>)}</div></div>
        <div className="control-section"><label>Color</label><div className="color-row">{colors.map(c=><button key={c} className={color===c?"color-dot selected":"color-dot"} style={{background:c}} onClick={()=>{setColor(c);tgHaptic()}}/>)}</div></div>
        <div className="control-section"><div className="slider-label"><label>Text size</label><span>{size}px</span></div><input type="range" min="28" max="110" value={size} onChange={e=>setSize(+e.target.value)}/></div>
        <div className="control-section"><div className="slider-label"><label>Speed</label><span>{speed.toFixed(1)}s</span></div><input type="range" min=".3" max="3" step=".1" value={speed} onChange={e=>setSpeed(+e.target.value)}/></div>
        <div className="toggle-row"><div><strong>Loop animation</strong><span>Repeat continuously</span></div><button className={loop?"toggle on":"toggle"} onClick={()=>{setLoop(!loop);tgHaptic()}}><span/></button></div>
        <button className="primary-button create-button" onClick={exportProject}>✨ Create Sticker</button>
      </section>
    </main>
    {picker&&<Picker selected={animationId} onSelect={id=>{setAnimationId(id);tgHaptic()}} onClose={()=>setPicker(false)}/>}
  </div>
}

function Home({onCreate,onCategory}){
  return <div className="home">
    <section className="hero"><div className="hero-badge">✨ TEXT ANIMATION STUDIO</div><h1>Make your text<span> come alive.</span></h1><p>Create animated text, stickers and emoji directly from your phone.</p><button className="primary-button hero-button" onClick={onCreate}>✨ Create Animation</button></section>
    <section className="section"><div className="section-header"><h2>Explore</h2><p>Choose your animation style</p></div>
      <div className="category-grid">{categories.filter(c=>c[0]!=="all").map(([id,name,icon])=><button key={id} className="category-card" onClick={()=>onCategory(id)}><span className="category-icon">{icon}</span><span>{name}</span><span className="arrow">›</span></button>)}</div>
    </section>
    <section className="tip-card"><div className="tip-icon">💡</div><div><strong>Made for Telegram</strong><p>Create transparent animated stickers and emoji-ready designs.</p></div></section>
  </div>
}

function ExportPanel({project,onBack}){
  const exportType=type=>{tgHaptic("medium");alert(`${type} export will be connected to the rendering server in V2.`)};
  return <div className="export-page"><header className="topbar"><button className="icon-button" onClick={onBack}>‹</button><div className="topbar-title">Export</div><div style={{width:40}}/></header>
    <main className="export-content"><div className="export-preview"><div className="transparent-grid"/><div className="export-text" style={{color:project.color,fontFamily:project.font,fontSize:`${Math.min(project.size,72)}px`}}>{project.text}</div></div>
      <h2>Your creation 🎉</h2><p className="export-description">Choose where you want to use your animation.</p>
      <div className="export-options">
        <button className="export-option" onClick={()=>exportType("Telegram Emoji")}><span className="export-icon">😎</span><span><strong>Telegram Emoji</strong><small>Animated custom emoji</small></span><span>›</span></button>
        <button className="export-option" onClick={()=>exportType("Telegram Sticker")}><span className="export-icon">🎨</span><span><strong>Telegram Sticker</strong><small>Transparent animated sticker</small></span><span>›</span></button>
        <button className="export-option" onClick={()=>exportType("WEBM")}><span className="export-icon">🎬</span><span><strong>WEBM</strong><small>Transparent video</small></span><span>›</span></button>
      </div>
      <div className="coming-soon"><span>🚧</span><div><strong>Rendering server</strong><p>The next version will render your animation into a real transparent WEBM and send it directly to Telegram.</p></div></div>
      <button className="secondary-button" onClick={onBack}>← Continue editing</button>
    </main>
  </div>
}

function App(){
  const [page,setPage]=useState("home");
  const [selectedAnimation,setSelectedAnimation]=useState("bounce");
  const [project,setProject]=useState(null);
  useEffect(()=>initTelegram(),[]);
  const openEditor=(a="bounce")=>{setSelectedAnimation(a);setPage("editor")};
  return <div className="app">
    {page==="home"&&<><header className="app-header"><div className="brand"><div className="brand-icon">✨</div><div><strong>TextMotion</strong><span>Motion Studio</span></div></div><button className="icon-button">⚙️</button></header>
      <Home onCreate={()=>openEditor()} onCategory={()=>openEditor()}/>
      <nav className="bottom-nav"><button className="nav-item active"><span>⌂</span>Home</button><button className="nav-item" onClick={()=>openEditor()}><span>✨</span>Create</button><button className="nav-item"><span>♡</span>My</button></nav>
    </>}
    {page==="editor"&&<Editor initialAnimation={selectedAnimation} onBack={()=>setPage("home")} onExport={p=>{setProject(p);setPage("export")}}/>}
    {page==="export"&&project&&<ExportPanel project={project} onBack={()=>setPage("editor")}/>}
  </div>
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);