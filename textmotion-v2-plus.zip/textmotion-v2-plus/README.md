# TextMotion V2+
Added from the user's animation list:
- Sliding Text Reveal
- Text Extrusion
- Text Scroller
- Inflating Text
- Negative Mask Effect
- Bounce Period
- Sliding Time Reveal
- Animated Text Fill
- Neon Light Animation
- Animated Text Outline

Font Library:
- Upload custom .TTF/.OTF/.WOFF/.WOFF2 fonts directly in the browser.
- Uploaded fonts are registered with FontFace and become selectable immediately.

Note: this is still browser/CSS preview. Real transparent WEBM rendering is the next milestone.
